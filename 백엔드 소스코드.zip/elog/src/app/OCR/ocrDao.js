// 모든 유저 조회
// async function selectUser(connection) {
//   const selectUserListQuery = `
//                 SELECT email, nickname 
//                 FROM UserInfo;
//                 `;
//   const [userRows] = await connection.query(selectUserListQuery);
//   return userRows;
// }


// module.exports = {
//   selectUser,
// };
