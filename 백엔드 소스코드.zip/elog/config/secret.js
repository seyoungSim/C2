// TODO: 해당 KEY 값들을 꼭 바꿔서 사용해주세요!
// TODO: .gitignore에 추가하는거 앚지 마세요!
module.exports = {
    'jwtsecret' :  'softsquared_jwt_secret_key_07040014087',
    'OCR_API_URL': 'https://0b65140fc15a46a9840989b67847784e.apigw.ntruss.com/custom/v1/8832/3b346418c781089947a0042e75203af74b5d61383ba87b93e9656ee08a91b07c/general',
    'OCR_SECRET_KEY': 'ZVdYdVdOVEdmWWdQSVBMcFdpTG5MaWNhbFpYaUVMYUM=',
};